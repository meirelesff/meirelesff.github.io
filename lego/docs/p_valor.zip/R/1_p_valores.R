# ---
# 0 TESTES Z E T E CALCULO DE P-VALORES
# ---

# Neste exemplo, vamos testar uma hipotese a partir de uma amostra que geramos
# e utilizar p-valor pra avaliar quao extremo eh o resultado observado sob a
# hipotese nula. Vamos antes carregar o pacote de sempre:
library(tidyverse)


# Fixa a semente para o exemplo ser reprodutivel
set.seed(123)


# Primeiro, vamos imaginar o seguinte problema: sorteamos uma amostra aleatoria
# de pessoas em uma universidade para entrevistar e perguntamos pra cada uma delas
# quanto tempo por dia elas passam estudando. Pra facilitar o nosso exemplo,
# nos vamos criar o PGD para ser o seguinte: na populacao dessa universidade, 
# a media de horas estudadas serah de 6 horas, com desvio padrao de 2 e distri-
# buicao normal.
horas_populacao <- 6
desvio_populacao <- 2


# Agora, vamos tirar uma amostra de 30 pessoas da universidade:
n <- 30
amostra <- rnorm(n, horas_populacao, desvio_populacao)


# Qual e' a media de horas estudadas nessa amostra que tiramos?
media_amostra <- sum(amostra) / n


# E qual e' a variance (isto e', os desvios medios [-1] ao quadrado em relacao a media)?
variancia_amostra <- sum( (amostra - media_amostra)^2 ) / (n - 1)


# E qual e' o desvio-padrao (isto e', a raiz da variancia, que usamos para voltar
# a variancia para escala original da nossa variavel) e o erro-padrao (que leva
# em conta o N)?
desvio_amostra <- sqrt(variancia_amostra)
erro_amostra <- desvio_amostra / sqrt(n)
erro_populacao <- desvio_populacao / sqrt(n)


# Claro, poderiamos fazer tudo isso com funcoes do R:
mean(amostra) # Media
var(amostra)  # Variancia
sd(amostra)   # Desvio


# Com tudo calculado, digamos que queremos testar se a media de horas de estudo
# de estudantes dessa universidade eh diferente da media de horas de outra universidade,
# que vamos assumir ser de 4.5 horas. Para isso, vamos usar teste de hipoteses:

# h0: a media de horas da nossa universidade eh igual a media da outra universidade (4.5)
# h1: a media eh diferente

# Primeiro, vamos imaginar um teste z. Ele faz sentido quando conhecemos o desvio-
# padrao da populacao. Nesse caso, normalizamos a diferenca entre a media observada
# e o valor sob h0 usando o erro-padrao populacional. Calculamos o z-score como:
h0 <- 4.5
z <- (media_amostra - h0) / erro_populacao


# Isso nos retorna um numero que indica o quanto, em termos de desvio-padrao, 
# a media da nossa amostra esta distante do valor sob h0 usando uma metrica
# comum. Agora podemos usar a distribuicao cumulativa normal para
# esses parametros pra avaliar nosso z-score e derivar um p-valor. 

# O que e' mesmo a funcao cumulativa? Isso aqui:
x <- seq(-3, 3, by = 0.1)

cumulativa <- tibble(
  x = x,
  cumulativa = pnorm(x)
)

ggplot(cumulativa, aes(x = x, y = cumulativa)) +
  geom_line()


# Com a funcao 'pnorm', conseguimos saber qual a probabilidade de obtermos um 
# valor z menor ou igual que x. Vamos
# ver nosso z:
z


# E qual a probabilidade acumulada ate' ele?
pnorm(z)


# Podemos marcar ele no nosso grafico com a distribuicao cumulativo:
ggplot(cumulativa, aes(x = x, y = cumulativa)) +
  geom_line() +
  geom_vline(xintercept = z)


# Ou fazer um equivalente com a funcao de densidade:
ggplot(cumulativa, aes(x = x, y = dnorm(x))) +
  geom_line() +
  geom_vline(xintercept = z)


# Como queremos saber tanto se ele eh maior ou menor que h0, deixamos esse valor
# positivo (forcando ele a ser absoluto) e olhamos para as duas caudas da
# distribuicao normal:
z_absoluto <- abs(z)
p_valor_z <- 2 * pnorm(-z_absoluto)


# E aqui esta' o resultado do teste z:
p_valor_z


# Vale notar que o procedimento e' parecido com o teste t. A diferenca e' que,
# quando o desvio-padrao populacional nao e' conhecido, usamos o desvio-padrao
# da amostra para construir o erro-padrao. A estatistica t e' calculada como:
t <- (media_amostra - h0) / (desvio_amostra / sqrt(n))


# Como o t-score se distribui segundo a distribuicao T de Student, usamos a 
# funcao cumulativa 'pt', que tem um parametro de graus de liberdade --
# que e' o tamanho da nossa amostra menos 1.
t_absoluto <- abs(t)
p_valor_t <- 2 * pt(-t_absoluto, df = n - 1)


# O resultado e' diferente agora. Mas ele esta' certo? O R tem uma funcao 
# para calcular o teste T com duas caudas que podemos usar como sanity check:
t_teste_r <- t.test(amostra, mu = h0)
t_teste_r


# Compare os p-valores:
c(
  "Teste Z" = p_valor_z,
  "Teste T do R" = t_teste_r$p.value,
  "Nosso teste T" = p_valor_t
)


# De forma geral, quanto menor a amostra, maior a diferenca de p-valor entre o 
# teste T e o teste Z. Em amostras pequenas, o teste T costuma ser mais apropriado
# quando nao conhecemos o desvio-padrao da populacao.

# Importante sempre lembrar: p-valor nao e' a probabilidade de h0 ser correto.
# Ele e' a probabilidade, assumindo h0, de observarmos uma estatistica tao
# extrema quanto a observada, ou ainda mais extrema.
