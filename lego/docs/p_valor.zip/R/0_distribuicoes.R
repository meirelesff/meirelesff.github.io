# ---
# 0 SCRIPT COM EXEMPLO DE PMF PARA DISTRIBUICAO BINOMIAL
# ---

# Para esse exemplo, vamos precisar carregar o pacote tidyverse
library(tidyverse)


# Fixa a semente para o exemplo ser reprodutivel
set.seed(123)


# Vamos comecar de forma bem simples: um lancamento de moeda. Podemos usar
# a funcao rbinom, que gera sorteios a partir de uma distribuicao Binomial.
# Vale lembrar que precisamos definir quantos sorteios vamos fazer (nesse caso,
# vamos jogar a moeda pra cima uma vez apenas); quantas vezes queremos repetir
# esse processo (de novo, uma vez apenas); e, finalmente, precisamos especificar
# a probabilidade do resultado sair cara (0.5 para uma moeda sem vicio). Vamos
# assumir que 1 = cara e fazer alguns sorteios:
repeticoes <- 1
lancamentos <- 1
prob_cara <- 0.5
rbinom(repeticoes, lancamentos, prob_cara)


# Como jogamos a moeda apenas uma vez, isso eh o equivalente a uma variavel Bernoulli, que,
# como voce deve lembrar, consiste em apenas um lancamento com uma probabilidade
# de sucesso (i.e., de sair cara) definida.


# Agora, vamos modificar um pouco as coisas: vamos fazer 10 repeticoes do sorteio
# e anotar o resultado de cada um (novamente, se sair 1, considere que o resultado
# foi cara):
repeticoes <- 10
rbinom(repeticoes, lancamentos, prob_cara)


# Com o codigo acima, mudamos apenas o valor do objeto 'repeticoes' e, como re-
# sultado, tivemos 10 repeticoes do lancamento de moeda. Isso ainda sao sorteios
# Bernoulli repetidos. A distribuicao Binomial aparece quando contamos quantos
# sucessos ocorreram em uma sequencia de lancamentos independentes. Em vez de repetir o
# procedimento 10 vezes e anotar seus resultados, podemos fazer tudo de uma vez
# dizendo para a funcao que queremos uma sequencia de 10 lancamentos:
repeticoes <- 1
lancamentos <- 10
prob_cara <- 0.5
rbinom(repeticoes, lancamentos, prob_cara)


# O resultado agora eh diferente: ele ja' nos diz quantos lancamentos de moeda
# deram cara. Com isso em mente, podemos repetir o processo de 10 lancamentos
# 10 vezes:
repeticoes <- 10
lancamentos <- 10
prob_cara <- 0.5
rbinom(repeticoes, lancamentos, prob_cara)


# Se entendemos bem isso, podemos agora dar um passo adiante e repetir esse 
# processo 1000 vezes e salvar o resultado:
repeticoes <- 1000
lancamentos <- 10
prob_cara <- 0.5
x <- rbinom(repeticoes, lancamentos, prob_cara)
x


# Podemos agora fazer perguntas do tipo: fazendo sequencias de 10 lancamentos de
# moeda, e somando o numero de vezes que o resultado foi cara, e repetindo esse
# procedimento 1000 vezes, em quantas repeticoes o resultado foi igual a 5?
mean(x == 5)


# E em quantas foi 10?
mean(x == 10)


# Aqui uma forma de fazer esse calculo pra todos os valores possiveis
distribuicao_empirica <- tibble(x = x) |>
  count(x, name = "n") |>
  mutate(prop = n / repeticoes)

distribuicao_empirica |>
  ggplot(aes(x = x, y = prop)) +
  geom_col() +
  scale_x_continuous(breaks = 0:10) 


# Essa eh uma distribuicao empirica, isto eh, ela eh baseada em sorteios reais
# a partir de uma distribuicao Binomial -- ha' variacao em cada lancamento e,
# por isso, resultados podem ser diferentes se fizermos o processo novamente.


# Isso eh diferente da distribuicao teorica que aprendemos em sala de aula. Isso
# nos podemos calcular com 'dbinom', que nos da' a probabilidade esperada de obter 
# exatamente o valor 'x' em 'n' lancamentos com probabilidade de sucesso em cada
# lancamento de 'p'.


# Vamos fazer um teste e, para isso, vamos pedir para a funcao calcular a prob.
# esperada de obter exatamente 5 caras em 10 lancamentos de moeda sequenciais:
dbinom(5, lancamentos, prob_cara)


# E, agora, a prob. esperada de obter apenas 1 cara em 10 lancamentos:
dbinom(1, lancamentos, prob_cara)


# E, finalmente, a prob. de obter cada um dos resultados possiveis (e.g., 1 cara,
# 2 caras, 3 caras...)
distribuicao_teorica <- dbinom(0:10, lancamentos, prob_cara)


# Vamos comparar ela com a distribuicao empirica que obtivemos antes?
distribuicao_empirica |>
  ggplot(aes(x = x, y = prop)) +
  geom_col() +
  geom_col(data = tibble(x = 0:10, y = distribuicao_teorica),
           aes(x = x, y = y), fill = "orange", alpha = 0.7) +
  scale_x_continuous(breaks = 0:10) 


# Sabendo como gerar uma distribuicao empirica a partir de uma distribuicao
# binomial, e sabendo como obter a funcao de massa de probabilidade teorica, podemos 
# refazer o processo todo:
x <- rbinom(repeticoes, lancamentos, prob_cara)

distribuicao_empirica <- tibble(x = x) |>
  count(x, name = "n") |>
  mutate(prop = n / repeticoes)

distribuicao_teorica <- dbinom(0:10, lancamentos, prob_cara)

distribuicao_empirica |>
  ggplot(aes(x = x, y = prop)) +
  geom_col() +
  geom_col(data = tibble(x = 0:10, y = distribuicao_teorica),
           aes(x = x, y = y), fill = "orange", alpha = 0.7) +
  scale_x_continuous(breaks = 0:10) 

