# ---
# 0 SCRIPT COM EXEMPLOS BASICOS DE _join PARA PRATICAR
# ---


# Para esse exemplo, vamos precisar carregar o pacote dplyr (lembre-se que 'e
# ele que contem as funcoes _join)
library(dplyr)


# O pacote tambem tem algumas bases de dados que sao uteis para testar _join. 
# Slao elas:
View(band_instruments)
View(band_instruments2)
View(band_members)


# Como da' para ver, essas bases contem membros e instrumentistas de duas bandas
# populares (mas antigas), e o objetivo didatico geral delas e' permitir que
# usar diferentes tipos de _join para linkar bandas -- membros -- instrumentos.
# Vamos comecar os exemplos.


# left_join
# Exemplo: combinar membros da banda com seus instrumentos (band_instruments)
exemplo_left_join <- band_members |>
  left_join(band_instruments, by = join_by(name))

View(exemplo_left_join)


# right_join
# Exemplo: relacionar instrumentos com os membros da banda(band_instruments2)
# (note que os nomes das variaveis sao diferentes, entao usamos outra sintaxe)
exemplo_right_join <- band_members |>
  right_join(band_instruments2, by = join_by(name == artist))

View(exemplo_right_join)


# full_join
# Exemplo: combinar todas as informações de band_instruments e band_instruments2
exemplo_full_join <- band_instruments |>
  full_join(band_instruments2, by = join_by(name == artist))

View(exemplo_full_join)


# inner_join
# Exemplo: membros da banda que aparecem em ambas as bases
exemplo_inner_join <- band_instruments |>
  inner_join(band_instruments2, by = join_by(name == artist))

View(exemplo_inner_join)







