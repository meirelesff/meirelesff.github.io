# Template de relatórios para o Laboratório de Eleições

O arquivo [artigo.qmd](artigo.qmd) é um exemplo de relatório acadêmico em
[Quarto](https://quarto.org/). Ele combina texto, referências, código em `R`,
gráficos, tabelas e resultados em um único arquivo.

## Instalação

Para usar o template, instale:

- [R](https://cran.r-project.org/);
- [RStudio](https://posit.co/download/rstudio-desktop/), se desejar trabalhar em
  uma interface gráfica;
- [Quarto](https://quarto.org/docs/get-started/), escolhendo o instalador adequado
  ao seu sistema operacional;
- [TinyTeX](https://quarto.org/docs/output-formats/pdf-engine.html), necessário
  para gerar o PDF.

Depois, no R, instale os pacotes usados pelo exemplo:

```r
install.packages(c("tidyverse", "knitr", "tinytex"))
tinytex::install_tinytex()
```

## Uso

Abra `template_quarto.Rproj` no RStudio e edite `artigo.qmd`. O PDF é o primeiro
formato indicado no arquivo e, por isso, é o formato padrão do botão `Render`. O
HTML pode ser escolhido no menu do botão e é autocontido, podendo ser aberto
diretamente em um navegador.

Para gerar os dois formatos pelo terminal, execute:

```bash
quarto render artigo.qmd
```

Para gerar apenas um formato:

```bash
quarto render artigo.qmd --to html
quarto render artigo.qmd --to pdf
```

Também é possível usar o pacote `quarto` no R, embora ele não seja necessário
para executar o comando do terminal:

```r
install.packages("quarto")
quarto::quarto_render("artigo.qmd")
```

Substitua o texto do exemplo pela pergunta, pelos dados e pela análise do grupo.
Mantenha a seção de uso de LLMs, registrando ferramentas, tarefas e partes do
relatório em que elas foram utilizadas.
